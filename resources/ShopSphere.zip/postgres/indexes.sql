-- ==============================================================================
-- ShopSphere PostgreSQL Indexing & Optimization Script
-- ==============================================================================

-- 1. Baseline Performance Test (Before Index)
EXPLAIN ANALYZE
SELECT *
FROM orders
WHERE customer_id = 1;

-- 2. Create B-Tree Index on Foreign Key
CREATE INDEX IF NOT EXISTS idx_orders_customer
ON orders(customer_id);

-- 3. Post-Index Performance Test (After Index)
EXPLAIN ANALYZE
SELECT *
FROM orders
WHERE customer_id = 1;
