-- ==============================================================================
-- ShopSphere Synthetic Transaction Generator
-- Generates 100,000 realistic orders to meet the ≥10,000 records capstone requirement
-- ==============================================================================

INSERT INTO orders (customer_id, order_date, status)
SELECT
    1 + floor(random() * 5)::INT,
    DATE '2026-01-01' + floor(random() * 240)::INT,
    'Completed'
FROM generate_series(1, 100000);

-- Verify record count
SELECT COUNT(*) AS total_orders FROM orders;
