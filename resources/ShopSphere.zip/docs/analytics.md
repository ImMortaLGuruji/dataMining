# ShopSphere: Business Intelligence & Analytics Report

This document records the business questions, analytical SQL queries, and empirical findings produced from the ShopSphere dimensional star schema.

---

## 1. Revenue by Product Category

**Question:** Which product categories generate the highest net revenue?

```sql
SELECT
    p.category,
    ROUND(SUM(f.net_amount), 2) AS revenue
FROM fact_sales f
JOIN dim_product p
    ON f.product_key = p.product_key
GROUP BY p.category
ORDER BY revenue DESC;
```

**Results:**
| Category | Net Revenue (INR) | % of Total Revenue |
| :--- | :---: | :---: |
| **Electronics** | ₹139,660.00 | 83.5% |
| **Furniture** | ₹27,600.00 | 16.5% |

_Insight: Electronics constitutes over four-fifths of platform gross margins, driven by high-ticket items like Laptops._

---

## 2. Top 10 Customers by Total Spend

**Question:** Which customers contribute the most revenue to the platform?

```sql
SELECT
    c.customer_name,
    c.city,
    ROUND(SUM(f.net_amount), 2) AS total_spend
FROM fact_sales f
JOIN dim_customer c
    ON f.customer_key = c.customer_key
GROUP BY c.customer_name, c.city
ORDER BY total_spend DESC
LIMIT 10;
```

**Results:**
| Rank | Customer Name | City | Total Net Spend (INR) |
| :---: | :--- | :--- | :---: |
| **1** | Ravi Kumar | Bangalore | ₹89,610.00 |
| **2** | Priya Patel | Ahmedabad | ₹63,750.00 |
| **3** | Rahul Singh | Mumbai | ₹11,400.00 |
| **4** | Anita Sharma | Mysore | ₹2,500.00 |

_Insight: The top two customers (Ravi Kumar and Priya Patel) account for ~91% of total sales revenue._

---

## 3. Top Products by Volume Sold

**Question:** Which products move the highest number of units?

```sql
SELECT
    p.product_name,
    p.category,
    SUM(f.quantity) AS units_sold
FROM fact_sales f
JOIN dim_product p
    ON f.product_key = p.product_key
GROUP BY p.product_name, p.category
ORDER BY units_sold DESC
LIMIT 10;
```

**Results:**
| Product Name | Category | Units Sold |
| :--- | :--- | :---: |
| **Mouse** | Electronics | 2 |
| **Laptop** | Electronics | 2 |
| **Keyboard** | Electronics | 1 |
| **Desk** | Furniture | 1 |
| **Office Chair** | Furniture | 1 |

---

## 4. Average Order Value (AOV)

**Question:** What is the average net financial value of each completed sale?

```sql
SELECT
    ROUND(SUM(net_amount) / COUNT(DISTINCT sale_id), 2) AS average_order_value
FROM fact_sales;
```

**Result:**

- **Average Order Value:** **₹27,876.67**

---

## 5. High-Sales, Low-Stock Inventory Alerts

**Question:** Which products are selling well but have inventory levels below safety threshold (< 30 units)?

```sql
SELECT
    p.product_name,
    SUM(f.quantity) AS units_sold,
    i.stock_quantity
FROM fact_sales f
JOIN dim_product p
    ON f.product_key = p.product_key
JOIN read_csv('s3://shopsphere/raw/inventory/inventory.csv') i
    ON f.product_key = i.product_id
GROUP BY p.product_name, i.stock_quantity
HAVING i.stock_quantity < 30
ORDER BY units_sold DESC;
```

**Results:**
| Product Name | Units Sold | Current Warehouse Stock | Alert Status |
| :--- | :---: | :---: | :--- |
| **Laptop** | 2 | 25 units | ⚠️ Low Inventory Warning |
| **Desk** | 1 | 20 units | ⚠️ Low Inventory Warning |

_Actionable Recommendation: Immediately trigger warehouse replenishment orders for Laptops (Bangalore) and Desks (Mumbai)._
