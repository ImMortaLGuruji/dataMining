# MinIO Setup & Administration Guide

## Accessing the MinIO Web Console

1. Navigate to: [http://localhost:9001](http://localhost:9001)
2. Log in with:
   - **Username:** `admin`
   - **Password:** `admin12345`

---

## Automated Management with MinIO Client (`mc`)

MinIO Client (`mc`) is bundled directly inside the `shopsphere-minio` container. You can execute management tasks directly via Docker:

### 1. Set Local Alias

```bash
docker exec shopsphere-minio mc alias set local http://localhost:9000 admin admin12345
```

### 2. Verify Bucket

```bash
docker exec shopsphere-minio mc ls local/
```

### 3. Inspect Directory Tree

```bash
docker exec shopsphere-minio mc tree local/shopsphere
```
