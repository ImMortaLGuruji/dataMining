# ShopSphere MinIO Data Lake Architecture

## Bucket Configuration

- **Bucket Name:** `shopsphere`
- **S3 API Endpoint:** `http://localhost:9000`
- **Web Console UI:** `http://localhost:9001`
- **Root Credentials:**
  - **Access Key / User:** `admin`
  - **Secret Key / Password:** `admin12345`

---

## Logical Folder Hierarchy & Storage Zones

```text
shopsphere/
│
├── raw/                                     # Raw Landing Zone (Immutable Source Data)
│   ├── sales/                               # Transaction line items (sales.csv)
│   ├── inventory/                           # Warehouse stock counts (inventory.csv)
│   └── campaigns/                           # Promotion metadata (campaigns.json)
│
├── processed/                               # Staging / Intermediate Transformations
│
└── curated/                                 # Business-Ready Analytical Zone (Parquet)
    ├── fact_sales.parquet                   # Curated sales fact table
    ├── dim_customer.parquet                 # Curated customer dimension
    └── dim_product.parquet                  # Curated product dimension
```

---

## Storage Zone Specifications

### 1. Raw Zone (`raw/`)

- **Format:** Native raw file formats (CSV, JSON).
- **Access Policy:** Read-only for analytical pipelines.
- **Contract:** Unmodified source extracts loaded directly from upstream systems.

### 2. Processed Zone (`processed/`)

- **Format:** Staged or deduplicated data.
- **Purpose:** Temporary staging area for intermediate transformation steps if required.

### 3. Curated Zone (`curated/`)

- **Format:** Apache Parquet with columnar compression (Snappy) and dictionary encoding.
- **Access Policy:** Read-optimized for downstream BI tools, dashboards, and analytical SQL engines (DuckDB).
