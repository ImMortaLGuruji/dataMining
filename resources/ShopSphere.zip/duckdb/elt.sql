-- ==============================================================================
-- ShopSphere ELT Pipeline: Curating Analytical Star Schema to Parquet
-- ==============================================================================
-- Architecture:
-- Raw Data (MinIO S3) + Operational Data (PostgreSQL)
--    ↓
-- In-Engine Transformation (DuckDB Vectorized SQL)
--    ↓
-- Curated Analytical Layer (MinIO Columnar Parquet)
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 1. Export Fact and Dimension Tables to Curated Parquet Storage
-- ------------------------------------------------------------------------------

COPY fact_sales
TO 's3://shopsphere/curated/fact_sales.parquet'
(FORMAT PARQUET);

COPY dim_customer
TO 's3://shopsphere/curated/dim_customer.parquet'
(FORMAT PARQUET);

COPY dim_product
TO 's3://shopsphere/curated/dim_product.parquet'
(FORMAT PARQUET);

COPY dim_date
TO 's3://shopsphere/curated/dim_date.parquet'
(FORMAT PARQUET);

-- ------------------------------------------------------------------------------
-- 2. Verify Direct Querying Against Curated Parquet Objects (Zero-Copy BI Access)
-- ------------------------------------------------------------------------------

-- Direct scan on curated sales fact
SELECT
    sale_id,
    customer_key,
    product_key,
    date_key,
    quantity,
    unit_price,
    discount,
    gross_amount,
    net_amount
FROM read_parquet('s3://shopsphere/curated/fact_sales.parquet')
LIMIT 5;

-- Direct analytical join across Parquet files
SELECT
    p.category,
    COUNT(f.sale_id) AS total_sales_count,
    SUM(f.quantity) AS total_units_sold,
    ROUND(SUM(f.gross_amount), 2) AS total_gross_revenue,
    ROUND(SUM(f.net_amount), 2) AS total_net_revenue
FROM read_parquet('s3://shopsphere/curated/fact_sales.parquet') f
JOIN read_parquet('s3://shopsphere/curated/dim_product.parquet') p
    ON f.product_key = p.product_key
GROUP BY p.category
ORDER BY total_net_revenue DESC;
