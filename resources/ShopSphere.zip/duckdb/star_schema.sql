-- ==============================================================================
-- ShopSphere Dimensional Star Schema Modeling
-- ==============================================================================
-- Fact Table Grain:
-- "One row represents one product line sold in one order."
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 1. Create Customer Dimension (dim_customer)
-- ------------------------------------------------------------------------------
CREATE OR REPLACE TABLE dim_customer AS
SELECT
    customer_id AS customer_key,
    customer_name,
    email,
    city,
    state
FROM pg.public.customers;

-- ------------------------------------------------------------------------------
-- 2. Create Product Dimension (dim_product)
-- ------------------------------------------------------------------------------
CREATE OR REPLACE TABLE dim_product AS
SELECT
    product_id AS product_key,
    product_name,
    category,
    price
FROM pg.public.products;

-- ------------------------------------------------------------------------------
-- 3. Create Date Dimension (dim_date)
-- ------------------------------------------------------------------------------
CREATE OR REPLACE TABLE dim_date AS
SELECT
    CAST(d AS DATE) AS date_key,
    YEAR(CAST(d AS DATE)) AS year,
    MONTH(CAST(d AS DATE)) AS month,
    MONTHNAME(CAST(d AS DATE)) AS month_name,
    DAY(CAST(d AS DATE)) AS day
FROM generate_series(
    DATE '2026-01-01',
    DATE '2026-12-31',
    INTERVAL 1 DAY
) t(d);

-- ------------------------------------------------------------------------------
-- 4. Create Sales Fact Table (fact_sales)
-- ------------------------------------------------------------------------------
CREATE OR REPLACE TABLE fact_sales AS
SELECT
    s.sale_id,
    o.customer_id AS customer_key,
    s.product_id AS product_key,
    CAST(s.sale_date AS DATE) AS date_key,
    s.quantity,
    p.price AS unit_price,
    s.discount,
    (s.quantity * p.price) AS gross_amount,
    (s.quantity * p.price * (1 - s.discount)) AS net_amount
FROM read_csv('s3://shopsphere/raw/sales/sales.csv') s
JOIN pg.public.orders o
    ON s.order_id = o.order_id
JOIN pg.public.products p
    ON s.product_id = p.product_id;

-- ------------------------------------------------------------------------------
-- 5. Validation & Record Counts
-- ------------------------------------------------------------------------------
SELECT 'dim_customer' AS table_name, COUNT(*) AS record_count FROM dim_customer
UNION ALL
SELECT 'dim_product' AS table_name, COUNT(*) AS record_count FROM dim_product
UNION ALL
SELECT 'dim_date' AS table_name, COUNT(*) AS record_count FROM dim_date
UNION ALL
SELECT 'fact_sales' AS table_name, COUNT(*) AS record_count FROM fact_sales;

SELECT * FROM fact_sales;
