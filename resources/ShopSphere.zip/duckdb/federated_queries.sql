-- ==============================================================================
-- ShopSphere Federated Analytical Queries
-- Demonstrates zero-copy cross-system queries joining PostgreSQL (OLTP) and MinIO (S3)
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- Federated Query 1: Sales Transactions enriched with Customers, Products, and Orders
-- ------------------------------------------------------------------------------
SELECT
    o.order_id,
    c.customer_name,
    c.city,
    p.product_name,
    p.category,
    s.quantity,
    p.price AS unit_price,
    s.discount,
    (s.quantity * p.price * (1 - s.discount)) AS final_amount
FROM read_csv('s3://shopsphere/raw/sales/sales.csv') s
JOIN pg.public.orders o
    ON s.order_id = o.order_id
JOIN pg.public.customers c
    ON o.customer_id = c.customer_id
JOIN pg.public.products p
    ON s.product_id = p.product_id;

-- ------------------------------------------------------------------------------
-- Federated Query 2: Product Catalog & Warehouse Inventory vs Active Order Quantities
-- ------------------------------------------------------------------------------
SELECT
    p.product_id,
    p.product_name,
    i.warehouse,
    i.stock_quantity,
    COALESCE(SUM(oi.quantity), 0) AS total_units_ordered
FROM pg.public.products p
JOIN read_csv('s3://shopsphere/raw/inventory/inventory.csv') i
    ON p.product_id = i.product_id
LEFT JOIN pg.public.order_items oi
    ON p.product_id = oi.product_id
GROUP BY p.product_id, p.product_name, i.warehouse, i.stock_quantity;

-- ------------------------------------------------------------------------------
-- Federated Query 3: Promotional Campaign Discount Comparison
-- ------------------------------------------------------------------------------
SELECT
    s.sale_id,
    p.product_name,
    s.discount AS applied_sale_discount,
    cmp.campaign_name,
    cmp.discount AS campaign_discount_rate
FROM read_csv('s3://shopsphere/raw/sales/sales.csv') s
JOIN pg.public.products p
    ON s.product_id = p.product_id
CROSS JOIN read_json('s3://shopsphere/raw/campaigns/campaigns.json') cmp
WHERE s.discount >= cmp.discount;
