-- ==============================================================================
-- ShopSphere Business Analytics Queries
-- Executive and operational business insights derived from the dimensional model
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 1. Revenue by Category
-- Question: Which product categories generate the highest net revenue?
-- ------------------------------------------------------------------------------
SELECT
    p.category,
    ROUND(SUM(f.net_amount), 2) AS revenue
FROM fact_sales f
JOIN dim_product p
    ON f.product_key = p.product_key
GROUP BY p.category
ORDER BY revenue DESC;

-- ------------------------------------------------------------------------------
-- 2. Top 10 Customers by Total Spend
-- Question: Which customers contribute the most revenue to the platform?
-- ------------------------------------------------------------------------------
SELECT
    c.customer_name,
    c.city,
    ROUND(SUM(f.net_amount), 2) AS total_spend
FROM fact_sales f
JOIN dim_customer c
    ON f.customer_key = c.customer_key
GROUP BY c.customer_name, c.city
ORDER BY total_spend DESC
LIMIT 10;

-- ------------------------------------------------------------------------------
-- 3. Top 10 Products by Volume Sold
-- Question: Which products have the highest unit sales volume?
-- ------------------------------------------------------------------------------
SELECT
    p.product_name,
    p.category,
    SUM(f.quantity) AS units_sold
FROM fact_sales f
JOIN dim_product p
    ON f.product_key = p.product_key
GROUP BY p.product_name, p.category
ORDER BY units_sold DESC
LIMIT 10;

-- ------------------------------------------------------------------------------
-- 4. Average Order Value (AOV)
-- Question: What is the average net financial value of each completed sale?
-- ------------------------------------------------------------------------------
SELECT
    ROUND(SUM(net_amount) / COUNT(DISTINCT sale_id), 2) AS average_order_value
FROM fact_sales;

-- ------------------------------------------------------------------------------
-- 5. High-Sales, Low-Stock Inventory Alerts
-- Question: Which products are selling well but have inventory below safety threshold (< 30 units)?
-- ------------------------------------------------------------------------------
SELECT
    p.product_name,
    SUM(f.quantity) AS units_sold,
    i.stock_quantity
FROM fact_sales f
JOIN dim_product p
    ON f.product_key = p.product_key
JOIN read_csv('s3://shopsphere/raw/inventory/inventory.csv') i
    ON f.product_key = i.product_id
GROUP BY p.product_name, i.stock_quantity
HAVING i.stock_quantity < 30
ORDER BY units_sold DESC;
