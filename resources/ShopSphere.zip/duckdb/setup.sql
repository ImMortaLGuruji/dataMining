-- ==============================================================================
-- ShopSphere DuckDB Connection & Extension Setup
-- ==============================================================================

-- 1. Install and load PostgreSQL extension
INSTALL postgres;
LOAD postgres;

-- 2. Attach PostgreSQL database as schema 'pg'
ATTACH 'host=localhost port=5432 dbname=shopsphere user=shopsphere password=shopsphere' AS pg (TYPE postgres);

-- 3. Install and load HTTPFS / S3 extension
INSTALL httpfs;
LOAD httpfs;

-- 4. Create S3 Secret for MinIO Object Storage
CREATE OR REPLACE SECRET minio_secret (
    TYPE S3,
    KEY_ID 'admin',
    SECRET 'admin12345',
    ENDPOINT 'localhost:9000',
    URL_STYLE 'path',
    USE_SSL false
);
