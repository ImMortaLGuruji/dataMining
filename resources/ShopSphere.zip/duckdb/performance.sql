-- ==============================================================================
-- ShopSphere Query Performance Analysis (DuckDB Vectorized Execution Plan)
-- ==============================================================================

EXPLAIN
SELECT
    p.category,
    SUM(f.net_amount) AS revenue
FROM fact_sales f
JOIN dim_product p
    ON f.product_key = p.product_key
GROUP BY p.category;
