# ShopSphere - Modern Data Lakehouse

> A local, end-to-end Modern Data Lakehouse for e-commerce analytics built with PostgreSQL, MinIO, DuckDB, Docker, and Parquet.

---

## Table of Contents

- [1. Project Overview](#1-project-overview)
- [2. Problem Statement & Architecture](#2-problem-statement--architecture)
- [3. Technology Stack](#3-technology-stack)
- [4. Prerequisites](#4-prerequisites)
- [5. Quick Start (Step-by-Step Guide)](#5-quick-start-step-by-step-guide)
- [6. Docker Infrastructure Deployment](#6-docker-infrastructure-deployment)
- [7. PostgreSQL Operational Database (OLTP)](#7-postgresql-operational-database-oltp)
- [8. MinIO Data Lake Storage](#8-minio-data-lake-storage)
- [9. Raw Datasets (CSV & JSON)](#9-raw-datasets-csv--json)
- [10. DuckDB Analytical Engine Setup](#10-duckdb-analytical-engine-setup)
- [11. Federated Querying](#11-federated-querying)
- [12. Dimensional Modeling & Star Schema](#12-dimensional-modeling--star-schema)
- [13. Curated Parquet Storage](#13-curated-parquet-storage)
- [14. ELT Pipeline Workflow](#14-elt-pipeline-workflow)
- [15. Business Analytics Queries](#15-business-analytics-queries)
- [16. Query Performance & Access Methods](#16-query-performance--access-methods)
- [17. Data Generation (Scaling to ≥10,000 Records)](#17-data-generation-scaling-to-10000-records)
- [18. Solo Developer Ownership & Workflow](#18-solo-developer-ownership--workflow)
- [19. Implementation Roadmap (Phases 1–10)](#19-implementation-roadmap-phases-110)
- [20. Repository Structure](#20-repository-structure)
- [21. End-to-End Validation Checklist](#21-end-to-end-validation-checklist)
- [22. Capstone Submission Requirements](#22-capstone-submission-requirements)
- [23. Troubleshooting Guide](#23-troubleshooting-guide)
- [24. Project Philosophy & Future Extensions](#24-project-philosophy--future-extensions)
- [25. Complete Run Guide (Phase 1 to Phase 10)](#25-complete-run-guide-phase-1-to-phase-10)

---

# 1. Project Overview

**ShopSphere** is an end-to-end Modern Data Lakehouse capstone project simulating the complete analytical data platform of an e-commerce enterprise.

Built as a self-contained, reproducible project by a **single data engineer**, it demonstrates the entire data lifecycle:

1. Maintaining operational transactional data in **PostgreSQL**.
2. Storing raw structured and semi-structured external datasets in **MinIO** object storage.
3. Using **DuckDB** as an embedded analytical query engine to execute federated SQL directly across heterogeneous storage layers without prior ETL ingestion.
4. Implementing an in-engine **ELT pipeline** to model business data into a dimensional **Star Schema**.
5. Persisting curated analytical tables in columnar **Parquet** format back into MinIO.
6. Deriving executive business analytics and studying low-level **query execution plans and indexes**.

```text
                    SHOPSPHERE MODERN DATA PLATFORM

 ┌─────────────────────┐       ┌─────────────────────┐
 │     PostgreSQL      │       │       MinIO         │
 │   Operational DB    │       │     Data Lake       │
 │                     │       │                     │
 │  customers          │       │  raw/               │
 │  products           │       │  processed/         │
 │  orders             │       │  curated/           │
 │  order_items        │       │                     │
 └──────────┬──────────┘       └──────────┬──────────┘
            │                             │
            │ (Port 5432)                 │ (Port 9000 S3 API)
            └──────────────┬──────────────┘
                           │
                           ▼
                  ┌─────────────────┐
                  │     DuckDB      │
                  │                 │
                  │ Federated SQL   │
                  │ In-Engine ELT   │
                  │ Analytical SQL  │
                  └────────┬────────┘
                           │
                           ▼
                  ┌─────────────────┐
                  │   Star Schema   │
                  │                 │
                  │ fact_sales      │
                  │ dim_customer    │
                  │ dim_product     │
                  │ dim_date        │
                  │ dim_location    │
                  └────────┬────────┘
                           │
                           ▼
                  ┌─────────────────┐
                  │ Curated Parquet │
                  │ Storage (MinIO) │
                  └────────┬────────┘
                           │
                           ▼
                  ┌─────────────────┐
                  │ Business BI &   │
                  │ Performance SQL │
                  └─────────────────┘
```

---

# 2. Problem Statement & Architecture

Modern e-commerce platforms ingest information from multiple disjoint systems:

- Transactional records (customers, products, checkout orders) are processed in ACID-compliant OLTP relational engines.
- External logs, partner inventory feeds, and ad-hoc campaign exports are deposited into distributed object storage.

Traditional architectures require heavyweight ETL pipelines to copy every record into an expensive centralized data warehouse before analytics can take place.

**The ShopSphere Lakehouse approach solves this by:**

- Keeping operational transactional data in **PostgreSQL**.
- Storing raw multi-format files in **MinIO** (S3-compatible object storage).
- Using **DuckDB** for zero-copy, federated queries combining live operational tables with object-store files.
- Executing **ELT transformations** directly in the analytical engine to build a star schema.
- Curating optimized **Parquet** files for long-term analytical workloads.
- Benchmarking query plans (`EXPLAIN` / `EXPLAIN ANALYZE`) and evaluating index access methods.

---

# 3. Technology Stack

| Technology           | Role                          | Purpose in ShopSphere                                                                                                |
| :------------------- | :---------------------------- | :------------------------------------------------------------------------------------------------------------------- |
| **PostgreSQL 16**    | Operational OLTP Database     | Manages transactional entities (`customers`, `products`, `orders`, `order_items`) with referential integrity.        |
| **MinIO**            | S3 Object Storage / Data Lake | Provides S3-compatible raw, processed, and curated storage tiers (`raw/`, `processed/`, `curated/`).                 |
| **DuckDB**           | Embedded Analytical Engine    | Executes fast vectorized analytics, federated queries across PostgreSQL & MinIO, ELT transforms, and Parquet writes. |
| **Docker & Compose** | Container Infrastructure      | Delivers a 100% reproducible local multi-container environment.                                                      |
| **Parquet**          | Columnar Analytical Format    | Stores high-performance curated dimensional tables with columnar compression and predicate pushdown.                 |
| **CSV & JSON**       | Raw External Data             | Represents external operational extracts (sales CSV, warehouse inventory CSV, campaign JSON).                        |
| **SQL**              | Unified Query Interface       | Used for DDL schemas, seed data generation, federated joins, star-schema creation, and business reporting.           |

---

# 4. Prerequisites

Before starting, ensure your system has:

- **Operating System:** Windows 10/11, macOS, or Linux.
- **Docker Desktop:** Installed and running with at least 4 GB RAM assigned (8 GB recommended).
- **DuckDB CLI:** Installed and added to system `PATH` (v0.9.x+ recommended), or an analytical SQL client like DBeaver.
- **Git & Terminal:** PowerShell, bash, or zsh.

### Verify Prerequisites:

```bash
docker --version
docker compose version
duckdb --version
```

---

# 5. Quick Start (Step-by-Step Guide)

For a single engineer building ShopSphere from scratch, follow these six core steps:

```bash
# 1. Clone repository and navigate to workspace
git clone https://github.com/ImMortaLGuruji/ShopSphere.git
cd ShopSphere

# 2. Start PostgreSQL and MinIO
docker compose up -d

# 3. Verify containers are healthy
docker ps

# 4. Verify PostgreSQL tables and seed data
docker exec -it shopsphere-postgres psql -U shopsphere -d shopsphere -c "\dt"

# 5. Log in to MinIO Console (http://localhost:9001 -> admin / admin12345)
# Create bucket 'shopsphere' and upload data/ files into:
#   raw/sales/sales.csv
#   raw/inventory/inventory.csv
#   raw/campaigns/campaigns.json

# 6. Launch DuckDB and run analytical pipeline
duckdb
```

Within DuckDB:

```sql
-- Attach PostgreSQL and configure MinIO S3 secret
INSTALL postgres; LOAD postgres;
ATTACH 'host=localhost port=5432 dbname=shopsphere user=shopsphere password=shopsphere' AS pg (TYPE postgres);

INSTALL httpfs; LOAD httpfs;
CREATE SECRET minio_secret (
    TYPE S3,
    KEY_ID 'admin',
    SECRET 'admin12345',
    ENDPOINT 'localhost:9000',
    URL_STYLE 'path',
    USE_SSL false
);

-- Test federated query across PostgreSQL and MinIO
SELECT o.order_id, c.customer_name, p.product_name, s.quantity, p.price, s.discount
FROM read_csv('s3://shopsphere/raw/sales/sales.csv') s
JOIN pg.public.orders o ON s.order_id = o.order_id
JOIN pg.public.customers c ON o.customer_id = c.customer_id
JOIN pg.public.products p ON s.product_id = p.product_id;
```

---

# 6. Docker Infrastructure Deployment

The infrastructure is defined in a single `docker-compose.yml` file deploying PostgreSQL 16 and the MinIO object store.

### `docker-compose.yml`

```yaml
services:
  postgres:
    image: postgres:16
    container_name: shopsphere-postgres
    environment:
      POSTGRES_USER: shopsphere
      POSTGRES_PASSWORD: shopsphere
      POSTGRES_DB: shopsphere
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./postgres/init.sql:/docker-entrypoint-initdb.d/init.sql

  minio:
    image: minio/minio:latest
    container_name: shopsphere-minio
    environment:
      MINIO_ROOT_USER: admin
      MINIO_ROOT_PASSWORD: admin12345
    ports:
      - "9000:9000"
      - "9001:9001"
    command: server /data --console-address ":9001"
    volumes:
      - minio_data:/data

volumes:
  postgres_data:
  minio_data:
```

### Stack Management Commands

```bash
# Start all services in the background
docker compose up -d

# Inspect running containers
docker ps

# Check logs
docker compose logs postgres
docker compose logs minio

# Stop the stack
docker compose down

# Wipe volumes and rebuild from scratch (resets PostgreSQL data & init.sql)
docker compose down -v
docker compose up -d
```

---

# 7. PostgreSQL Operational Database (OLTP)

PostgreSQL holds the normalized operational transactional data model. When the container starts for the first time with an empty volume, `postgres/init.sql` initializes the tables and seeds initial rows.

### `postgres/init.sql`

```sql
-- Operational Schema DDL
CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    customer_name VARCHAR(100),
    email VARCHAR(150),
    city VARCHAR(100),
    state VARCHAR(100),
    created_at DATE
);

CREATE TABLE products (
    product_id SERIAL PRIMARY KEY,
    product_name VARCHAR(150),
    category VARCHAR(100),
    price DECIMAL(10,2)
);

CREATE TABLE orders (
    order_id SERIAL PRIMARY KEY,
    customer_id INT REFERENCES customers(customer_id),
    order_date DATE,
    status VARCHAR(50)
);

CREATE TABLE order_items (
    order_item_id SERIAL PRIMARY KEY,
    order_id INT REFERENCES orders(order_id),
    product_id INT REFERENCES products(product_id),
    quantity INT,
    unit_price DECIMAL(10,2)
);

-- Seed Data
INSERT INTO customers (customer_name, email, city, state, created_at) VALUES
('Ravi Kumar', 'ravi@example.com', 'Bangalore', 'Karnataka', '2026-01-10'),
('Anita Sharma', 'anita@example.com', 'Mysore', 'Karnataka', '2026-02-15'),
('Rahul Singh', 'rahul@example.com', 'Mumbai', 'Maharashtra', '2026-03-20'),
('Priya Patel', 'priya@example.com', 'Ahmedabad', 'Gujarat', '2026-04-05'),
('Arjun Rao', 'arjun@example.com', 'Hyderabad', 'Telangana', '2026-05-12');

INSERT INTO products (product_name, category, price) VALUES
('Laptop', 'Electronics', 75000.00),
('Mouse', 'Electronics', 1200.00),
('Keyboard', 'Electronics', 2500.00),
('Office Chair', 'Furniture', 12000.00),
('Desk', 'Furniture', 18000.00);

INSERT INTO orders (customer_id, order_date, status) VALUES
(1, '2026-08-01', 'Completed'),
(2, '2026-08-02', 'Completed'),
(3, '2026-08-05', 'Completed'),
(1, '2026-08-10', 'Completed'),
(4, '2026-08-15', 'Completed');

INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
(1, 1, 1, 75000.00),
(1, 2, 2, 1200.00),
(2, 3, 1, 2500.00),
(3, 4, 1, 12000.00),
(4, 5, 1, 18000.00),
(5, 1, 1, 75000.00);
```

### Verify PostgreSQL:

```bash
docker exec -it shopsphere-postgres psql -U shopsphere -d shopsphere
```

```sql
\dt
SELECT * FROM customers;
SELECT * FROM products;
SELECT * FROM orders;
SELECT * FROM order_items;
\q
```

---

# 8. MinIO Data Lake Storage

MinIO serves as the S3-compatible data lake storage layer.

- **MinIO Console UI:** [http://localhost:9001](http://localhost:9001)
- **MinIO S3 API Endpoint:** `http://localhost:9000`
- **Root User:** `admin`
- **Root Password:** `admin12345`

### Data Lake Bucket & Zones

Create a bucket named `shopsphere` with the following logical prefix hierarchy:

```text
shopsphere/
├── raw/
│   ├── sales/
│   │   └── sales.csv
│   ├── inventory/
│   │   └── inventory.csv
│   └── campaigns/
│       └── campaigns.json
├── processed/
└── curated/
    ├── fact_sales.parquet
    ├── dim_customer.parquet
    └── dim_product.parquet
```

- **`raw/`**: Unmodified source datasets from external platforms.
- **`processed/`**: Staged or intermediate transformations.
- **`curated/`**: Cleaned, partitioned, high-performance columnar Parquet datasets ready for business analytics.

---

# 9. Raw Datasets (CSV & JSON)

The following datasets represent external feeds uploaded to MinIO.

### 9.1 `data/sales.csv`

Stored in: `raw/sales/sales.csv`

```csv
sale_id,order_id,product_id,sale_date,quantity,discount
1,1,1,2026-08-01,1,0.05
2,1,2,2026-08-01,2,0.10
3,2,3,2026-08-02,1,0.00
4,3,4,2026-08-05,1,0.05
5,4,5,2026-08-10,1,0.10
6,5,1,2026-08-15,1,0.15
```

### 9.2 `data/inventory.csv`

Stored in: `raw/inventory/inventory.csv`

```csv
product_id,warehouse,stock_quantity
1,Bangalore,25
2,Bangalore,100
3,Mysore,50
4,Hyderabad,30
5,Mumbai,20
```

### 9.3 `data/campaigns.json`

Stored in: `raw/campaigns/campaigns.json`

```json
[
  {
    "campaign_id": 1,
    "campaign_name": "Independence Sale",
    "discount": 0.15
  },
  {
    "campaign_id": 2,
    "campaign_name": "Monsoon Sale",
    "discount": 0.1
  }
]
```

---

# 10. DuckDB Analytical Engine Setup

DuckDB runs locally as a serverless analytical SQL engine. It uses official extensions to attach directly to PostgreSQL via libpq and to MinIO via S3 HTTPFS.

```bash
# Launch interactive DuckDB shell
duckdb
```

### Configure PostgreSQL & MinIO Access

```sql
-- 1. Install & load PostgreSQL extension
INSTALL postgres;
LOAD postgres;

-- 2. Attach PostgreSQL as schema 'pg'
ATTACH 'host=localhost port=5432 dbname=shopsphere user=shopsphere password=shopsphere'
AS pg (TYPE postgres);

-- Test PostgreSQL connection
SELECT * FROM pg.public.customers;
SELECT * FROM pg.public.products;

-- 3. Install & load S3/HTTPFS extension
INSTALL httpfs;
LOAD httpfs;

-- 4. Create S3 secret for local MinIO
CREATE SECRET minio_secret (
    TYPE S3,
    KEY_ID 'admin',
    SECRET 'admin12345',
    ENDPOINT 'localhost:9000',
    URL_STYLE 'path',
    USE_SSL false
);

-- Test MinIO S3 access
SELECT * FROM read_csv('s3://shopsphere/raw/sales/sales.csv');
SELECT * FROM read_csv('s3://shopsphere/raw/inventory/inventory.csv');
SELECT * FROM read_json('s3://shopsphere/raw/campaigns/campaigns.json');
```

---

# 11. Federated Querying

Federated querying allows querying disparate systems in a single SQL query without copying or migrating data beforehand.

```text
MinIO (S3 CSV) ──┐
                 ├──> DuckDB Execution Engine ──> Unified Result Set
PostgreSQL (PG) ─┘
```

### Federated Query 1: Sales Enriched with Customers & Products

```sql
SELECT
    o.order_id,
    c.customer_name,
    c.city,
    p.product_name,
    p.category,
    s.quantity,
    p.price AS unit_price,
    s.discount,
    (s.quantity * p.price * (1 - s.discount)) AS final_amount
FROM read_csv('s3://shopsphere/raw/sales/sales.csv') s
JOIN pg.public.orders o
    ON s.order_id = o.order_id
JOIN pg.public.customers c
    ON o.customer_id = c.customer_id
JOIN pg.public.products p
    ON s.product_id = p.product_id;
```

### Federated Query 2: Product Stock vs. Active Orders

```sql
SELECT
    p.product_id,
    p.product_name,
    i.warehouse,
    i.stock_quantity,
    COALESCE(SUM(oi.quantity), 0) AS total_units_ordered
FROM pg.public.products p
JOIN read_csv('s3://shopsphere/raw/inventory/inventory.csv') i
    ON p.product_id = i.product_id
LEFT JOIN pg.public.order_items oi
    ON p.product_id = oi.product_id
GROUP BY p.product_id, p.product_name, i.warehouse, i.stock_quantity;
```

### Federated Query 3: Campaign Discount Comparison

```sql
SELECT
    s.sale_id,
    p.product_name,
    s.discount AS applied_sale_discount,
    cmp.campaign_name,
    cmp.discount AS campaign_discount_rate
FROM read_csv('s3://shopsphere/raw/sales/sales.csv') s
JOIN pg.public.products p
    ON s.product_id = p.product_id
CROSS JOIN read_json('s3://shopsphere/raw/campaigns/campaigns.json') cmp
WHERE s.discount >= cmp.discount;
```

---

# 12. Dimensional Modeling & Star Schema

To facilitate reporting, DuckDB transforms the operational and raw data into an analytical **Star Schema**.

```text
                         ┌──────────────────┐
                         │   dim_customer   │
                         └────────┬─────────┘
                                  │
                                  ▼
┌──────────────────┐     ┌──────────────────┐     ┌──────────────────┐
│     dim_date     │────>│    fact_sales    │<────│   dim_product    │
└──────────────────┘     └──────────────────┘     └──────────────────┘
```

### Fact Table Grain

> **Grain Definition:** One row in `fact_sales` represents **one product line sold in one order**.

---

### Step 1: Create `dim_customer`

```sql
CREATE TABLE dim_customer AS
SELECT
    customer_id AS customer_key,
    customer_name,
    email,
    city,
    state
FROM pg.public.customers;
```

### Step 2: Create `dim_product`

```sql
CREATE TABLE dim_product AS
SELECT
    product_id AS product_key,
    product_name,
    category,
    price
FROM pg.public.products;
```

### Step 3: Create `dim_date`

```sql
CREATE TABLE dim_date AS
SELECT
    CAST(d AS DATE) AS date_key,
    YEAR(CAST(d AS DATE)) AS year,
    MONTH(CAST(d AS DATE)) AS month,
    MONTHNAME(CAST(d AS DATE)) AS month_name,
    DAY(CAST(d AS DATE)) AS day
FROM generate_series(
    DATE '2026-01-01',
    DATE '2026-12-31',
    INTERVAL 1 DAY
) t(d);
```

### Step 4: Create `fact_sales`

```sql
CREATE TABLE fact_sales AS
SELECT
    s.sale_id,
    o.customer_id AS customer_key,
    s.product_id AS product_key,
    CAST(s.sale_date AS DATE) AS date_key,
    s.quantity,
    p.price AS unit_price,
    s.discount,
    (s.quantity * p.price) AS gross_amount,
    (s.quantity * p.price * (1 - s.discount)) AS net_amount
FROM read_csv('s3://shopsphere/raw/sales/sales.csv') s
JOIN pg.public.orders o
    ON s.order_id = o.order_id
JOIN pg.public.products p
    ON s.product_id = p.product_id;
```

### Validate Star Schema:

```sql
SELECT COUNT(*) FROM dim_customer;
SELECT COUNT(*) FROM dim_product;
SELECT COUNT(*) FROM dim_date;
SELECT COUNT(*) FROM fact_sales;
SELECT * FROM fact_sales LIMIT 5;
```

---

# 13. Curated Parquet Storage

Parquet is an open-source columnar storage format offering compression, dictionary encoding, and column projection/predicate pushdown.

Curate the tables into MinIO's `curated/` directory directly from DuckDB:

```sql
-- Export dimensional star schema as Parquet
COPY fact_sales
TO 's3://shopsphere/curated/fact_sales.parquet'
(FORMAT PARQUET);

COPY dim_customer
TO 's3://shopsphere/curated/dim_customer.parquet'
(FORMAT PARQUET);

COPY dim_product
TO 's3://shopsphere/curated/dim_product.parquet'
(FORMAT PARQUET);
```

### Verify Direct Parquet Querying:

```sql
-- Query Parquet files directly via S3 API
SELECT *
FROM read_parquet('s3://shopsphere/curated/fact_sales.parquet')
LIMIT 5;

SELECT
    category,
    COUNT(*) AS product_count,
    AVG(price) AS average_price
FROM read_parquet('s3://shopsphere/curated/dim_product.parquet')
GROUP BY category;
```

---

# 14. ELT Pipeline Workflow

ShopSphere implements an **ELT (Extract, Load, Transform)** architecture:

```text
  [Extract & Load]           [Transform in DuckDB]          [Curate & Analyze]
 Operational DB & Files       Vectorized SQL ELT          Columnar Storage
 ┌────────────────────┐     ┌─────────────────────┐     ┌───────────────────┐
 │ PostgreSQL Tables  │────>│  Federated Joins    │────>│  Curated Parquet  │
 │ MinIO Raw Files    │     │  Grain Aggregations │     │  BI SQL Queries   │
 └────────────────────┘     │  Star-Schema DDL    │     └───────────────────┘
                            └─────────────────────┘
```

**Why ELT instead of traditional ETL?**

1. **Zero-Copy Ingestion:** Raw files are placed in object storage immediately without pre-processing.
2. **Pushdown Engine Power:** DuckDB's vectorized columnar execution engine performs joins and aggregations orders of magnitude faster than Python or row-based tools.
3. **Reproducibility:** Transformations are recorded as pure declarative SQL files that can be version-controlled and rerun idempotently.

---

# 15. Business Analytics Queries

The following queries answer key operational and executive business questions using the dimensional model:

### 15.1 Revenue by Category

_Which product categories generate the highest net revenue?_

```sql
SELECT
    p.category,
    SUM(f.net_amount) AS revenue
FROM fact_sales f
JOIN dim_product p
    ON f.product_key = p.product_key
GROUP BY p.category
ORDER BY revenue DESC;
```

### 15.2 Top 10 Customers by Spend

_Which customers contribute the most revenue to the platform?_

```sql
SELECT
    c.customer_name,
    c.city,
    SUM(f.net_amount) AS total_spend
FROM fact_sales f
JOIN dim_customer c
    ON f.customer_key = c.customer_key
GROUP BY c.customer_name, c.city
ORDER BY total_spend DESC
LIMIT 10;
```

### 15.3 Top 10 Products by Volume Sold

_Which products move the highest number of units?_

```sql
SELECT
    p.product_name,
    SUM(f.quantity) AS units_sold
FROM fact_sales f
JOIN dim_product p
    ON f.product_key = p.product_key
GROUP BY p.product_name
ORDER BY units_sold DESC
LIMIT 10;
```

### 15.4 Average Order Value (AOV)

_What is the average financial value of each completed sale?_

```sql
SELECT
    SUM(net_amount) / COUNT(DISTINCT sale_id) AS average_order_value
FROM fact_sales;
```

### 15.5 High-Sales, Low-Stock Inventory Alerts

_Which items are selling well but have inventory levels below critical threshold (< 30 units)?_

```sql
SELECT
    p.product_name,
    SUM(f.quantity) AS units_sold,
    i.stock_quantity
FROM fact_sales f
JOIN dim_product p
    ON f.product_key = p.product_key
JOIN read_csv('s3://shopsphere/raw/inventory/inventory.csv') i
    ON f.product_key = i.product_id
GROUP BY p.product_name, i.stock_quantity
HAVING i.stock_quantity < 30
ORDER BY units_sold DESC;
```

---

# 16. Query Performance & Access Methods

A key objective of the project is understanding query execution plans and database access methods.

### 16.1 DuckDB Vectorized Execution Plan

Analyze the physical pipeline for the Category Revenue query in DuckDB:

```sql
EXPLAIN
SELECT
    p.category,
    SUM(f.net_amount) AS revenue
FROM fact_sales f
JOIN dim_product p
    ON f.product_key = p.product_key
GROUP BY p.category;
```

**Key Execution Stages to Identify:**

1. **`SEQ_SCAN`**: Columnar scan on `fact_sales` and `dim_product`.
2. **`HASH_JOIN`**: Vectorized in-memory hash join matching `product_key`.
3. **`HASH_GROUP_BY`**: Aggregating `SUM(net_amount)` by category.
4. **`PROJECTION`**: Final column selection and formatting.

---

### 16.2 PostgreSQL Index Experiment (`EXPLAIN ANALYZE`)

Execute inside PostgreSQL to compare index vs. sequential scan behavior:

```bash
docker exec -it shopsphere-postgres psql -U shopsphere -d shopsphere
```

```sql
-- Step 1: Run query without index
EXPLAIN ANALYZE
SELECT *
FROM orders
WHERE customer_id = 1;

-- Step 2: Create B-Tree index on foreign key
CREATE INDEX idx_orders_customer
ON orders(customer_id);

-- Step 3: Run query with index
EXPLAIN ANALYZE
SELECT *
FROM orders
WHERE customer_id = 1;
```

> [!NOTE]
> **Understanding the Optimizer:** If the table only has a few rows, the PostgreSQL cost optimizer may still select a `Seq Scan` over an `Index Scan` because scanning a single 8KB disk page is cheaper than reading both the index and table heap. Scale the dataset using Section 17 to see the optimizer switch to an `Index Scan` / `Bitmap Heap Scan`.

---

# 17. Data Generation (Scaling to ≥10,000 Records)

The capstone specification requires testing with at least **10,000 transactional records**. Run the following script in PostgreSQL to generate 100,000 realistic orders:

```sql
-- Connect to PostgreSQL container:
-- docker exec -it shopsphere-postgres psql -U shopsphere -d shopsphere

INSERT INTO orders (customer_id, order_date, status)
SELECT
    1 + floor(random() * 5)::INT,
    DATE '2026-01-01' + floor(random() * 240)::INT,
    'Completed'
FROM generate_series(1, 100000);

-- Verify record count
SELECT COUNT(*) FROM orders;
```

After generating orders, re-run the `EXPLAIN ANALYZE` experiment from Section 16.2 to observe the clear speedup and index utilization.

---

# 18. Solo Developer Ownership & Workflow

Building the entire platform as an individual engineer provides complete, full-stack mastery of the Modern Data Stack.

```text
 ┌────────────────────────────────────────────────────────────────────────┐
 │                    SOLO DATA ENGINEER DOMAIN                           │
 ├────────────────────────┬───────────────────────┬───────────────────────┤
 │  Infrastructure & OLTP │ Data Lake & Ingestion │ Analytics & Modeling  │
 │  • Docker Compose      • MinIO S3 Buckets      • DuckDB Extensions     │
 │  • PostgreSQL Schema   • CSV/JSON Data Prep    • Federated Joins       │
 │  • 10k+ Synthetic Data • S3 HTTPFS Secrets     • Star Schema DDL       │
 │  • B-Tree Index Tuning • Storage Zones         • Parquet Curated Layer │
 │  • EXPLAIN ANALYZE     • Object Management     • Business SQL & Perf   │
 └────────────────────────┴───────────────────────┴───────────────────────┘
```

### End-to-End Responsibilities:

1. **Platform Operations:** Setup and orchestrate multi-container services with Docker Compose.
2. **Database Engineering:** Design relational schemas, foreign key constraints, and performance indexes.
3. **Data Lake Architecture:** Structure multi-tiered object storage (`raw/`, `processed/`, `curated/`).
4. **Analytical Engineering:** Author clean, modular SQL scripts for zero-copy federation, dimensional modeling, and Parquet persistence.
5. **Quality Assurance:** Validate data integrity across storage boundaries and benchmark execution plans.

---

# 19. Implementation Roadmap (Phases 1–10)

Follow this linear 10-phase sequence to build and verify the project step by step:

| Phase  | Milestone                   | Actions                                                                    | Expected Deliverable                          |
| :----: | :-------------------------- | :------------------------------------------------------------------------- | :-------------------------------------------- |
| **1**  | **Repository Setup**        | Clone repo, create folders (`postgres/`, `data/`, `duckdb/`, `report/`).   | Initial workspace ready.                      |
| **2**  | **Infrastructure**          | Write `docker-compose.yml` and launch PostgreSQL & MinIO.                  | Both containers healthy (`docker ps`).        |
| **3**  | **Operational DB**          | Execute `init.sql` with tables, foreign keys, and seed rows.               | 4 operational tables verified via `psql`.     |
| **4**  | **Data Lake Setup**         | Log in to MinIO console (`:9001`), create `shopsphere` bucket and folders. | `raw/`, `processed/`, `curated/` initialized. |
| **5**  | **Raw Ingestion**           | Upload `sales.csv`, `inventory.csv`, and `campaigns.json` to MinIO.        | Files visible in MinIO bucket.                |
| **6**  | **DuckDB Federation**       | Attach PostgreSQL and MinIO secret in DuckDB; test federated joins.        | Zero-copy cross-system queries working.       |
| **7**  | **Dimensional Modeling**    | Create `dim_customer`, `dim_product`, `dim_date`, and `fact_sales`.        | Star schema verified in DuckDB.               |
| **8**  | **Parquet Curation**        | Export star schema tables to `s3://shopsphere/curated/*.parquet`.          | Columnar Parquet objects in MinIO.            |
| **9**  | **Data Scaling & Indexing** | Generate 10k+ orders in PostgreSQL; benchmark with `EXPLAIN ANALYZE`.      | Before/after index comparison logged.         |
| **10** | **Final Verification**      | Execute the 5 business queries and review the validation checklist.        | Capstone complete and documented.             |

---

# 20. Repository Structure

```text
shopsphere/
├── README.md                                      # Comprehensive project guide & specification
├── docker-compose.yml                             # Container infrastructure (PostgreSQL + MinIO)
│
├── postgres/
│   ├── init.sql                                   # Schema DDL, constraints, initial seed data
│   ├── generate_data.sql                          # Synthetic order generator (scales to 10k+ records)
│   └── indexes.sql                                # Performance indexing and tuning scripts
│
├── data/
│   ├── sales.csv                                  # External raw transaction extract
│   ├── inventory.csv                              # Warehouse stock levels
│   └── campaigns.json                             # Promotional campaign metadata
│
├── duckdb/
│   ├── setup.sql                                  # PostgreSQL & MinIO connection setup
│   ├── federated_queries.sql                      # Multi-source federated joins
│   ├── star_schema.sql                            # Dimension and fact table DDL
│   ├── analytics.sql                              # Business intelligence analytical queries
│   └── performance.sql                            # Vectorized EXPLAIN benchmarks
│
├── diagrams/
│   ├── architecture.png                           # System component flow diagram
│   └── star_schema.png                            # Fact-dimension entity relationship diagram
│
└── report/
    └── capstone_report.pdf                        # Final capstone report / findings document
```

---

# 21. End-to-End Validation Checklist

Verify your implementation against this 11-point inspection matrix:

| Checkpoint | Target Component          | Success Criteria                                                         | Verified |
| :--------: | :------------------------ | :----------------------------------------------------------------------- | :------: |
|   **1**    | **Docker Stack**          | `shopsphere-postgres` and `shopsphere-minio` running without restarts.   |   [x]    |
|   **2**    | **PostgreSQL Schema**     | `customers`, `products`, `orders`, `order_items` exist with constraints. |   [x]    |
|   **3**    | **Data Volume**           | At least 10,000 records populated in the PostgreSQL orders table.        |   [x]    |
|   **4**    | **MinIO Storage**         | `shopsphere` bucket contains raw sales, inventory, and campaign objects. |   [x]    |
|   **5**    | **DuckDB PG Connect**     | `SELECT * FROM pg.public.customers` returns rows inside DuckDB.          |   [x]    |
|   **6**    | **DuckDB S3 Connect**     | `SELECT * FROM read_csv('s3://...')` reads MinIO objects.                |   [x]    |
|   **7**    | **Federated SQL**         | Cross-source query joins PostgreSQL orders with MinIO sales CSV.         |   [x]    |
|   **8**    | **Star Schema**           | `fact_sales`, `dim_customer`, `dim_product`, `dim_date` created.         |   [x]    |
|   **9**    | **Parquet Layer**         | Curated Parquet files exported to `s3://shopsphere/curated/`.            |   [x]    |
|   **10**   | **Business Analytics**    | All 5 business queries execute and return valid metrics.                 |   [x]    |
|   **11**   | **Query Plans & Indexes** | `EXPLAIN` and `EXPLAIN ANALYZE` before/after index plans captured.       |   [x]    |

---

# 22. Capstone Submission Requirements

A complete project submission must include:

- [x] Functional `docker-compose.yml` defining reproducible services.
- [x] Operational schema and data generation script (≥10,000 records).
- [x] MinIO bucket structure containing raw and curated Parquet files.
- [x] DuckDB connection scripts for PostgreSQL and MinIO.
- [x] At least three documented federated queries.
- [x] Dimensional star schema with explicit grain definition.
- [x] At least five business analytical queries.
- [x] Query performance documentation (`EXPLAIN` and `EXPLAIN ANALYZE`).
- [x] At least one PostgreSQL index with before/after execution plan analysis.
- [x] Architecture diagram and Star Schema diagram in `diagrams/`.
- [x] Final Capstone Report in `report/`.

---

# 23. Troubleshooting Guide

### 1. PostgreSQL Container Fails to Run `init.sql`

- **Cause:** PostgreSQL only runs scripts in `/docker-entrypoint-initdb.d/` when the data volume is empty. If the container previously started, subsequent edits to `init.sql` are ignored.
- **Fix:** Wipe the volume and restart:
  ```bash
  docker compose down -v
  docker compose up -d
  ```

### 2. MinIO Web Console Does Not Open

- **Cause:** Connecting to the S3 API port instead of the web console port.
- **Fix:** Access the web console at [http://localhost:9001](http://localhost:9001). Port `9000` is reserved for S3 API requests from DuckDB.

### 3. DuckDB Fails to Attach PostgreSQL

- **Cause:** Port collision or incorrect credentials.
- **Fix:** Confirm PostgreSQL is published on port 5432 and test the connection using the CLI:
  ```bash
  docker exec -it shopsphere-postgres psql -U shopsphere -d shopsphere
  ```

### 4. DuckDB Cannot Connect to MinIO S3

- **Cause:** S3 endpoint syntax differs between DuckDB versions, or SSL is mistakenly enabled.
- **Fix:** In DuckDB, verify your version with `SELECT version();`. Ensure your `CREATE SECRET` command specifies `USE_SSL false` and `URL_STYLE 'path'`:
  ```sql
  CREATE SECRET minio_secret (
      TYPE S3,
      KEY_ID 'admin',
      SECRET 'admin12345',
      ENDPOINT 'localhost:9000',
      URL_STYLE 'path',
      USE_SSL false
  );
  ```

### 5. `read_csv` Works Locally but Fails on S3

- **Cause:** Object path mismatch or bucket does not exist.
- **Fix:** Verify in the MinIO UI ([http://localhost:9001](http://localhost:9001)) that the file exists at `shopsphere/raw/sales/sales.csv` and that the bucket name matches `s3://shopsphere/...`.

---

# 24. Project Philosophy & Future Extensions

ShopSphere demonstrates that modern data lakehouse architectures do not require massive clusters or cloud subscriptions to understand deeply. With modern open-source tools like DuckDB, MinIO, and PostgreSQL, an individual engineer can build, test, and benchmark a complete enterprise-grade data platform on a standard laptop.

### Potential Future Extensions:

- **Incremental ELT:** Use DuckDB to ingest and append only newly added files based on timestamps.
- **Data Quality Assertions:** Introduce automated checks in DuckDB for null foreign keys, negative prices, or abnormal discount values.
- **BI Visualization:** Connect Metabase, Apache Superset, or Evidence.dev to query the curated Parquet files directly.
- **Slowly Changing Dimensions (SCD):** Implement SCD Type 2 tracking for customer location changes or product price revisions.

---

# 25. Complete Run Guide (Phase 1 to Phase 10)

This run guide provides every terminal and SQL command required to execute the entire ShopSphere project sequentially from initial setup to final reporting.

---

### Phase 1: Repository & Workspace Setup
```bash
# Clone the repository and navigate into the project directory
git clone https://github.com/ImMortaLGuruji/ShopSphere.git
cd ShopSphere

# Create environment configuration file from template
# On Windows PowerShell:
Copy-Item .env.example .env
# On Linux/macOS:
# cp .env.example .env

# Verify that raw data files exist in data/
ls data/
```

---

### Phase 2: Docker Infrastructure Deployment
```bash
# Launch PostgreSQL 16 and MinIO in the background
docker compose up -d

# Verify both containers are running and healthy
docker ps

# (Optional) Verify service logs
docker compose logs postgres
docker compose logs minio
```

---

### Phase 3: PostgreSQL Operational Database (OLTP)
```bash
# Check that the 4 operational tables were initialized by init.sql
docker exec -it shopsphere-postgres psql -U shopsphere -d shopsphere -c "\dt"

# Scale the orders table to 100,005 records (satisfying the ≥10,000 requirement)
# On Windows PowerShell:
Get-Content postgres\generate_data.sql | docker exec -i shopsphere-postgres psql -U shopsphere -d shopsphere
# On Linux/macOS:
# docker exec -i shopsphere-postgres psql -U shopsphere -d shopsphere < postgres/generate_data.sql

# Verify table row statistics
docker exec shopsphere-postgres psql -U shopsphere -d shopsphere -c "SELECT relname AS table_name, n_live_tup AS row_count FROM pg_stat_user_tables ORDER BY relname;"
```

---

### Phase 4: MinIO Data Lake Setup
```bash
# Set local MinIO Client alias inside the container
docker exec shopsphere-minio mc alias set local http://localhost:9000 admin admin12345

# Create primary data lake bucket
docker exec shopsphere-minio mc mb local/shopsphere

# Verify bucket creation
docker exec shopsphere-minio mc ls local/
```

---

### Phase 5: Raw Ingestion to MinIO
```bash
# Copy local CSV and JSON files into container temporary storage
docker cp data/sales.csv shopsphere-minio:/tmp/sales.csv
docker cp data/inventory.csv shopsphere-minio:/tmp/inventory.csv
docker cp data/campaigns.json shopsphere-minio:/tmp/campaigns.json

# Copy files into their respective S3 prefixes (raw zone)
docker exec shopsphere-minio mc cp /tmp/sales.csv local/shopsphere/raw/sales/sales.csv
docker exec shopsphere-minio mc cp /tmp/inventory.csv local/shopsphere/raw/inventory/inventory.csv
docker exec shopsphere-minio mc cp /tmp/campaigns.json local/shopsphere/raw/campaigns/campaigns.json

# Clean up container temporary files
docker exec shopsphere-minio rm -f /tmp/sales.csv /tmp/inventory.csv /tmp/campaigns.json

# Verify uploaded files in MinIO
docker exec shopsphere-minio mc ls --recursive local/shopsphere/raw/
```

---

### Phase 6: DuckDB Setup & Federated Queries
```bash
# Attach PostgreSQL and MinIO S3, then execute 3 zero-copy federated queries
duckdb shopsphere.duckdb -c ".read duckdb/setup.sql" -c ".read duckdb/federated_queries.sql"
```

---

### Phase 7: Dimensional Modeling (Star Schema)
```bash
# Create dim_customer, dim_product, dim_date, and fact_sales tables
duckdb shopsphere.duckdb -c ".read duckdb/setup.sql" -c ".read duckdb/star_schema.sql"
```

---

### Phase 8: Curated Parquet Storage & In-Engine ELT
```bash
# Export star schema tables to compressed columnar Parquet in MinIO and test direct queries
duckdb shopsphere.duckdb -c ".read duckdb/setup.sql" -c ".read duckdb/elt.sql"

# Verify curated Parquet files in MinIO
docker exec shopsphere-minio mc ls local/shopsphere/curated/
```

---

### Phase 9: Business Analytics & Performance Analysis
```bash
# 1. Run all 5 executive business intelligence queries
duckdb shopsphere.duckdb -c ".read duckdb/setup.sql" -c ".read duckdb/analytics.sql"

# 2. Inspect DuckDB vectorized physical execution plan (EXPLAIN)
duckdb shopsphere.duckdb -c ".read duckdb/performance.sql"

# 3. Benchmark PostgreSQL indexing (EXPLAIN ANALYZE before/after index on 100k rows)
# On Windows PowerShell:
Get-Content postgres\indexes.sql | docker exec -i shopsphere-postgres psql -U shopsphere -d shopsphere
# On Linux/macOS:
# docker exec -i shopsphere-postgres psql -U shopsphere -d shopsphere < postgres/indexes.sql
```

---

### Phase 10: Final Verification & Teardown
```bash
# Inspect the entire MinIO data lake hierarchy
docker exec shopsphere-minio mc tree local/shopsphere

# Stop containers (preserves all data volumes)
docker compose down

# (Optional) Full teardown: wipe all containers and data volumes
# docker compose down -v
```

